import { useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { addNewPost } from "../../store/slices/postsSlice/postsSlice";
import {
  addNewPostForInitialUser,
  selectUsers,
} from "../../store/slices/usersSlice/usersSlice";

const AddNewPost = () => {
  const formRef = useRef(null);
  const { initialUser } = useSelector(selectUsers);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const submit = (e) => {
    e.preventDefault();

    if (formRef.current[0].value) {
      const newPost = {
        id: new Date().getTime().toString(),
        username: initialUser.username,
        description: formRef.current[1].value,
        img: formRef.current[0].value,
        likes: Math.floor(Math.random() * 1000),
        comments: [],
      };
      dispatch(addNewPost(newPost));
      dispatch(addNewPostForInitialUser(newPost));
      navigate("/main");
    }

    formRef.current[0].value = "";
    formRef.current[1].value = "";
  };

  return (
    <form ref={formRef} onSubmit={submit}>
      <input placeholder="for img" />
      <br></br>
      <input placeholder="for description" />
      <br></br>
      <button>Add new post</button>
    </form>
  );
};

export default AddNewPost;
