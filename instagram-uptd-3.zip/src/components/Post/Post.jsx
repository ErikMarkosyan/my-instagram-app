import "./Post.css";
import { faUser, faEllipsis } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { FiHeart } from "react-icons/fi";
import { FaRegComment, FaRegBookmark } from "react-icons/fa";
import { IoNavigateOutline } from "react-icons/io5";
import { BsEmojiSmile } from "react-icons/bs";
import withLessMore from "../../hoc/withLessMore";
import { useDispatch, useSelector } from "react-redux";
import { addComment } from "../../store/slices/postsSlice/postsSlice";
import {
  resetText,
  selectText,
  toggleText,
} from "../../store/slices/textSlice/textSlice";
import { selectUsers } from "../../store/slices/usersSlice/usersSlice";
import { useRef } from "react";

const Post = ({
  id,
  username,
  img,
  description,
  comments,
  show,
  toggleShow,
  likes,
  post,
}) => {
  const user = <FontAwesomeIcon icon={faUser} />;
  const dots = <FontAwesomeIcon icon={faEllipsis} />;
  const dispatch = useDispatch();
  const formRef = useRef(null);
  const { initialUser } = useSelector(selectUsers);

  const submit = (e) => {
    e.preventDefault();
    if (formRef.current[0].value) {
      dispatch(
        addComment({
          id: initialUser.id,
          username: initialUser.username,
          text: formRef.current[0].value,
        })
      );
      formRef.current[0].value = "";
    }
  };

  return (
    <div className={show ? "postsContainer" : "postContainerWithoutComments"}>
      <div className="postUserContainer">
        <div className="usernameAvatar">
          <p className="avatar">{user} </p>{" "}
          <p className="usernameUser">{username}</p>
          <p className="usernameDots">{dots}</p>
        </div>
      </div>
      <div className="postPicture">
        <img src={img} alt="postPicture" />
      </div>
      <div className="iconContainer">
        <ul className="iconUl">
          <li>{<FiHeart />}</li>
          <li>{<FaRegComment />}</li>
          <li>{<IoNavigateOutline />}</li>
          <ul className="bookmarkIcon">
            <li>{<FaRegBookmark />}</li>
          </ul>
        </ul>
      </div>
      <div className="likesContainer">
        <p>{likes} likes</p>
      </div>
      <div className="postSender">
        <h4>{username}</h4>
        &nbsp; &nbsp;
        <p>{description}</p>
      </div>
      <div className="postComments">
        <p onClick={toggleShow} className="showHideComment">
          {show ? "Hide comments" : `View all ${comments.length} comments`}
        </p>
        {show
          ? comments.map((el) => {
              return (
                <div className="postSender" key={el.id}>
                  <p>
                    <b>{el.username}</b>&nbsp;{el.body}
                  </p>
                </div>
              );
            })
          : null}
      </div>
      <div className="row"></div>
      <form ref={formRef} onSubmit={submit} className="addComment">
        {/* <div className="addComment"> */}
        <p className="emoji">{<BsEmojiSmile />}</p>
        <input
          placeholder="Add a comment..."
          // value={text}
          // onChange={(e) => dispatch(toggleText(e.target.value))}
          onFocus={() => {
            if (!show) {
              toggleShow();
            }
          }}
        />
        <button className="postComment">Post</button>
      </form>
      {/* </div> */}
    </div>
  );
};

export default withLessMore(Post);
