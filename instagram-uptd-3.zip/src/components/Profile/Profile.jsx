import "./Profile.css";
import { BsGearWide } from "react-icons/bs";
import {
  deletePostForInitialUser,
  selectUsers,
} from "../../store/slices/usersSlice/usersSlice";
import { useDispatch, useSelector } from "react-redux";
import { deletePost } from "../../store/slices/postsSlice/postsSlice";

const Profile = () => {
  const users = useSelector(selectUsers);
  const uniqeUser = users.initialUser;
  console.log(uniqeUser)
  const dispatch = useDispatch();
  return (
    <div className="container">
      <div className="profile">
        <div className="imgContainer">
          <img
            alt=""
            src="https://upload.wikimedia.org/wikipedia/commons/9/99/Sample_User_Icon.png"
          />
        </div>
        <div className="profileInfo">
          <p className="username">{uniqeUser.username}</p>
          <div className="usernameTools">
            <button className="editProfileButton">Edit Profile</button>
            <p className="gear">
              <BsGearWide />
            </p>
          </div>
          <div className="activeInfo">
            <p className="p1">
              <b>{uniqeUser.posts.length}</b> posts
            </p>
            <p className="p2">
              <b>200</b> followers
            </p>
            <p className="p3">
              <b>34</b> following
            </p>
          </div>
          <div className="bio">
            <h3 className="nameSurname">{uniqeUser.name}</h3>
            <p className="desc">{uniqeUser.about}</p>
          </div>
        </div>
      </div>
      <div className="row"></div>
      <div className="posts">
        {uniqeUser.posts.map((post) => {
          return (
            <div key={post.id} className="post">
              <img src={post.img} alt="" />
              <span
                className="del"
                onClick={() => {
                  dispatch(deletePostForInitialUser(post.id));
                  dispatch(deletePost(post.id));
                }}
              >
                &times;
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Profile;
