import {
  deleteAllMessages,
  deleteMessage,
  selectUsers,
  sendMessage,
} from "../../store/slices/usersSlice/usersSlice";
import { useDispatch, useSelector } from "react-redux";
import "./Chat.css";
import { useRef } from "react";

const Chat = () => {
  const { initialUser } = useSelector(selectUsers);
  const dispatch = useDispatch();
  const formRef = useRef(null);
  // const delAll = deleteAllMessages()

  const handleSubmit = (e) => {
    e.preventDefault();
    if (formRef.current[0].value !== "") {
      dispatch(sendMessage(formRef.current[0].value));
    }
    formRef.current[0].value = "";
  };

  return (
    <div className="chatContainer">
      <button onClick={() => dispatch(deleteAllMessages())}>
        Delete all messages
      </button>
      <div className="userInfo">
        <img
          src="https://upload.wikimedia.org/wikipedia/commons/9/99/Sample_User_Icon.png"
          alt=""
        />
        <h2>{initialUser.username}</h2>
      </div>
      <div className="chat">
        {initialUser.chat?.map((mes) => {
          return (
            <div>
              <p className={`${mes.user} chatMessage`}>
                {mes.text}
                &nbsp;
                {mes.user === "me" ? (
                  <span onClick={() => dispatch(deleteMessage(mes.id))}>
                    &times;
                  </span>
                ) : null}
              </p>
              <br></br>
            </div>
          );
        })}
      </div>
      <div className="inpButton">
        <form ref={formRef} onSubmit={handleSubmit}>
          <input placeholder="Message..." />
          {<button className="sendMessage">Send</button>}
        </form>
      </div>
    </div>
  );
};

export default Chat;
