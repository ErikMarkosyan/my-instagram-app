import { configureStore } from "@reduxjs/toolkit";
import { postsReducer } from "./slices/postsSlice/postsSlice";
import { textReducer } from "./slices/textSlice/textSlice";
import { usersReducer } from "./slices/usersSlice/usersSlice";

const store = configureStore({
  reducer: {
    posts: postsReducer,
    users: usersReducer,
    text: textReducer,
  },
});

export default store;
