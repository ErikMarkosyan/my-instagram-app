import { Route, Routes } from "react-router-dom";
import "./App.css";
import Profile from "./components/profile/Profile";
import Body from "./components/body/Body";
import Wrapper from "./pages/Wrapper";
import Login from "./components/login/Login";
import Chat from "./components/chat/Chat";

function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="/main" element={<Wrapper />}>
          <Route index element={<Body />} />
          <Route path="chat" element={<Chat />} />
          <Route path="profile" element={<Profile />} />
        </Route>
        <Route path="/" element={<Login />} />
        <Route path="*" element={<h1>Error 404</h1>} />
      </Routes>
    </div>
  );
}

export default App;
