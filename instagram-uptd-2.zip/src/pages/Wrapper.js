import { Outlet } from "react-router-dom";
import Header from "../components/head/Header";

const Wrapper = () => {
  return (
    <>
      <Header />
      <Outlet />
    </>
  );
};

export default Wrapper;
