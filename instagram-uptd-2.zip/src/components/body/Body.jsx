import "../body/Body.css";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  fetchPosts,
  selectPosts,
} from "../../store/slices/postsSlice/postsSlice";
import Posts from "../posts/Posts";

const Body = () => {
  const dispatch = useDispatch();
  const posts = useSelector(selectPosts);
  useEffect(() => {
    if (!posts.data.length) {
      dispatch(fetchPosts());
    }
  }, []);

  return (
    <div className="bodyContainer">
      <div className="storiesContainer">
        <div>
          <img
            src="https://images.unsplash.com/photo-1663267759119-7bf2c50dde00?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80"
            alt=""
          />
          <p>beautyblonde</p>
        </div>
        <div>
          <img
            src="https://images.unsplash.com/photo-1663267759119-7bf2c50dde00?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80"
            alt=""
          />
          <p>beautyblonde</p>
        </div>
        <div>
          <img
            src="https://images.unsplash.com/photo-1663267759119-7bf2c50dde00?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80"
            alt=""
          />
          <p>beautyblonde</p>
        </div>
        <div>
          <img
            src="https://images.unsplash.com/photo-1663267759119-7bf2c50dde00?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80"
            alt=""
          />
          <p>beautyblonde</p>
        </div>
      </div>

      {/* {---------------------------------------------------------------------} */}
      {posts.data.map((el) => {
        return (
          <Posts
            key={el.id}
            id={el.id}
            username={el.username}
            description={el.description}
            img={el.img}
            comments={el.comments}
          />
        );
      })}
      {/* <div className="postsContainer">
        <div className="postUserContainer">
          <div className="usernameAvatar">
            <p className="avatar">{user} </p>{" "}
            <p className="usernameUser">User</p>
            <p className="usernameDots">{dots}</p>
          </div>
        </div>
        <div className="postPicture">
          <img
            src="https://images.unsplash.com/photo-1510906594845-bc082582c8cc?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=844&q=80"
            alt="postPicture"
          />
        </div>
        <div className="iconContainer">
          <ul className="iconUl">
            <li>{<FiHeart />}</li>
            <li>{<FaRegComment />}</li>
            <li>{<IoNavigateOutline />}</li>
            <ul className="bookmarkIcon">
              <li>{<FaRegBookmark />}</li>
            </ul>
          </ul>
        </div>
        <div className="likesContainer">
          <p>1,250 likes</p>
        </div>
        <div className="postSender">
          <h4>Sender</h4>
          &nbsp; &nbsp;
          <p>Post</p>
        </div>
        <div className="postComments">
          <p>comments</p>
        </div>
        <div className="row"></div>
        <div className="addComment">
          <p className="emoji">{<BsEmojiSmile />}</p>
          <input placeholder="Add a comment..." />
          <p className="postComment">Post</p>
        </div>
      </div> */}
    </div>
  );
};

export default Body;
