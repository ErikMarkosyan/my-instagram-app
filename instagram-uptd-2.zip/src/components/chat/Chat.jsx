import {
  selectUsers,
  sendMessage,
} from "../../store/slices/usersSlice/usersSlice";
import { useDispatch, useSelector } from "react-redux";
import "./Chat.css";
import { useRef } from "react";
import ChatMessages from "../chatMessages/ChatMessages";

const Chat = () => {
  const {initialUser} = useSelector(selectUsers);
  console.log(initialUser);
  const dispatch = useDispatch;
  const formRef = useRef(null);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (formRef.current[0].value !== "") {
      dispatch(sendMessage(formRef.current[0].value));
    }
    formRef.current[0].value = "";
  };

  return (
    <div className="chatContainer">
      <div className="userInfo">
        <img
          src="https://upload.wikimedia.org/wikipedia/commons/9/99/Sample_User_Icon.png"
          alt=""
        />
        <h2>{initialUser.username}</h2>
      </div>
      <div className="chat">
        {initialUser.chat?.map((mes) => {
          return <ChatMessages key={mes.id} message={mes.message} sender={mes.sender}/>;
        })}
      </div>
      <div className="inpButton">
        <form ref={formRef} onSubmit={handleSubmit}>
          <input placeholder="Message..." />
          {<button className="sendMessage">Send</button>}
        </form>
      </div>
    </div>
  );
};

export default Chat;
