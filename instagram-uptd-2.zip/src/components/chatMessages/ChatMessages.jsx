import "./ChatMessages.css";

const ChatMessages = ({ id, message, sender }) => {
  return (
    <div>
      <p>{message}</p>
    </div>
  );
};

export default ChatMessages;
