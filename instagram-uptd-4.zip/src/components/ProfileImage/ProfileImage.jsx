import "./ProfileImage.css";

const ProfileImage = () => {
  return (
    <div className="imgContainer">
      <img
        alt=""
        src="https://upload.wikimedia.org/wikipedia/commons/9/99/Sample_User_Icon.png"
      />
    </div>
  );
};

export default ProfileImage;
