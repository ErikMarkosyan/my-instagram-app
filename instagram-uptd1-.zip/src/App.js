import { Route, Routes, useParams } from "react-router-dom";
import "./App.css";
import Profile from "./components/profile/Profile";
import Body from "./components/body/Body";
import Wrapper from "./pages/Wrapper";
import Login from "./components/login/Login";

function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/" element={<Wrapper />}>
          <Route index element={<Body />} />
          <Route path="/profile">
            <Route path=":id" element={<Profile />} />
          </Route>
        </Route>
        <Route path="*" element={<h1>Error 404</h1>} />
      </Routes>
    </div>
  );
}

export default App;
