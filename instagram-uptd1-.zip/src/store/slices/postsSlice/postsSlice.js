import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";

export const fetchPosts = createAsyncThunk(
  "posts/fetch-posts",
  async function () {
    const respPosts = await axios.get(
      "https://jsonplaceholder.typicode.com/photos"
    );
    const postsData = respPosts.data;

    const respComments = await axios.get(
      "https://jsonplaceholder.typicode.com/comments"
    );

    const commentsData = respComments.data;

    const data = postsData.map((el) => {
      return {
        id: el.id,
        username: el.title.slice(0, el.title.indexOf(" ")),
        description: el.title.slice(el.title.indexOf(" ") + 1),
        img: el.url,
        comments: commentsData
          .filter((comments) => comments.postId === el.id)
          .map((com) => ({
            id: com.id,
            body: com.body,
            username: com.name.slice(0, com.name.indexOf(" ")),
          })),
      };
    });

    return data;
    // console.log(data);
  }
);

const postsSlice = createSlice({
  name: "posts",
  initialState: {
    data: [],
    comment: "",
  },
  reducers: {
    addComment(state, { payload }) {
      console.log(state.comment)
      return {
        ...state,
        comments: [
           ...state.comments,
          {
            id: new Date().getTime().toString(),
            body: payload,
            username: "admin",
          },
        ],
        comment: "",
      };
    },
    toggleComment(state, { payload }) {
      console.log(payload)
      return {
        ...state,
        comment: payload,
      };
    },
  },
  extraReducers: {
    [fetchPosts.pending]: (state, { payload }) => {
      console.log("Loading ... ");
    },

    [fetchPosts.fulfilled]: (state, { payload }) => {
      return {
        ...state,
        data: [...payload],
      };
    },

    [fetchPosts.rejected]: (state, { payload }) => {
      console.log("some error");
    },
  },
});

export const selectPosts = (state) => state.posts;

export const selectComment = (state) => state.comment;

export const { addComment, toggleComment } = postsSlice.actions;

export const postsReducer = postsSlice.reducer;
