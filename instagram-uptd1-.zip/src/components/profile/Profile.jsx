import "../profile/Profile.css";
import { BsGearWide } from "react-icons/bs";
import { selectUsers } from "../../store/slices/usersSlice/usersSlice";
import { useSelector } from "react-redux";

const Profile = () => {
  const users = useSelector(selectUsers);
  const uniqeUser = users.initialUser;
  console.log(uniqeUser);
  return (
    <div className="container">
      <div className="profile">
        <div className="imgContainer">
          <img
            alt=""
            src="https://upload.wikimedia.org/wikipedia/commons/9/99/Sample_User_Icon.png"
          />
        </div>
        <div className="profileInfo">
          <p className="username">{uniqeUser.username}</p>
          <div className="usernameTools">
            <button className="editProfileButton">Edit Profile</button>
            <p className="gear">
              <BsGearWide />
            </p>
          </div>
          <div className="activeInfo">
            <p className="p1">
              <b>121</b> posts
            </p>
            <p className="p2">
              <b>200</b> followers
            </p>
            <p className="p3">
              <b>34</b> following
            </p>
          </div>
          <div className="bio">
            <h3 className="nameSurname">{uniqeUser.name}</h3>
            <p className="desc">{uniqeUser.about}</p>
          </div>
        </div>
      </div>
      <div className="row"></div>
      <div className="posts">
        {uniqeUser.posts.map((post) => {
          return (
            <div key={post.id} className="post">
              <img src={post.img} alt="" />
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Profile;
