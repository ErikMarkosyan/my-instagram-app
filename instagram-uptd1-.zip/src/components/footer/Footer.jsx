const Footer = () => {
  return (
    <div>
      <p>© 2022 INSTAGRAM FROM META</p>
    </div>
  );
};

export default Footer;
