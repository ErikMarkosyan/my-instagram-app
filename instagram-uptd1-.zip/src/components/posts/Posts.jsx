import "../posts/Posts.css";
import { faUser, faEllipsis } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { FiHeart } from "react-icons/fi";
import { FaRegComment, FaRegBookmark } from "react-icons/fa";
import { IoNavigateOutline } from "react-icons/io5";
import { BsEmojiSmile } from "react-icons/bs";
import withLessMore from "../../hoc/withLessMore";
import { useDispatch } from "react-redux";
import {
  addComment,
  toggleComment,
} from "../../store/slices/postsSlice/postsSlice";

const Posts = ({
  id,
  username,
  img,
  description,
  comments,
  show,
  toggleShow,
}) => {
  const user = <FontAwesomeIcon icon={faUser} />;
  const dots = <FontAwesomeIcon icon={faEllipsis} />;
  const dispatch = useDispatch();

  return (
    <div className={show ? "postsContainer" : "postContainerWithoutComments"}>
      <div className="postUserContainer">
        <div className="usernameAvatar">
          <p className="avatar">{user} </p>{" "}
          <p className="usernameUser">{username}</p>
          <p className="usernameDots">{dots}</p>
        </div>
      </div>
      <div className="postPicture">
        <img src={img} alt="postPicture" />
      </div>
      <div className="iconContainer">
        <ul className="iconUl">
          <li>{<FiHeart />}</li>
          <li>{<FaRegComment />}</li>
          <li>{<IoNavigateOutline />}</li>
          <ul className="bookmarkIcon">
            <li>{<FaRegBookmark />}</li>
          </ul>
        </ul>
      </div>
      <div className="likesContainer">
        <p>1,250 likes</p>
      </div>
      <div className="postSender">
        <h4>{username}</h4>
        &nbsp; &nbsp;
        <p>{description}</p>
      </div>
      <div className="postComments">
        <p onClick={toggleShow} className="showHideComment">
          {show ? "Hide comments" : `View all ${comments.length} comments`}
        </p>
        {show
          ? comments.map((el) => {
              return (
                <div className="postSender" key={el.id}>
                  <p>
                    <b>{el.username}</b>&nbsp;{el.body}
                  </p>
                </div>
              );
            })
          : null}
      </div>
      <div className="row"></div>
      <div className="addComment">
        <p className="emoji">{<BsEmojiSmile />}</p>
        <input
          placeholder="Add a comment..."
          onChange={(e) => dispatch(toggleComment(e.target.value))}
        />
        <p
          className="postComment"
          onClick={() => dispatch(addComment(addComment))}
        >
          Post
        </p>
      </div>
    </div>
  );
};

export default withLessMore(Posts);
