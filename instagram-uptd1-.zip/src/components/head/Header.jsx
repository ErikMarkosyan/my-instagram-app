import "../head/Header.css";
import Navbar from "../navbar/Navbar";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faMagnifyingGlass } from "@fortawesome/free-solid-svg-icons";
import { Link } from "react-router-dom";
import { IoIosArrowDown } from "react-icons/io";

const Header = () => {
  const searchIcon = <FontAwesomeIcon icon={faMagnifyingGlass} />;
  return (
    <div className="header">
      <div className="headerContainer">
        <Link to="/">
          <img
            className="logoName"
            src="https://www.logo.wine/a/logo/Instagram/Instagram-Wordmark-Black-Logo.wine.svg"
            alt="instagram"
          />
        </Link>
        <span className="arrowDown">
          <IoIosArrowDown />
        </span>
        <span className="searchContainer">
          <input
            className="headerSearch"
            placeholder="Search"
            onFocus={(e) => (e.target.placeholder = "")}
            onBlur={(e) => (e.target.placeholder = "Search")}
          />
          <span className="headerSearchIcon">{searchIcon}</span>
        </span>
        <Navbar className="headerNavbar" />
      </div>
    </div>
  );
};

export default Header;
